class Comment < ApplicationRecord
end
