class Song < ApplicationRecord
end
